# Bounce for Google™

[![Available on Chrome Webstore](available.png)](https://chrome.google.com/webstore/detail/agario-pro-controls/ebfgomdbkgplpibohofdgjdkkpflccde)

               O  G
            O        L
    Make G             E bounce!

This extension adds a nice touch to Google Search by making the Google letters from the logo bounce.

Might not work when there is a doodle.

Available in all 200+ local Google Search domains such as google.es, google.co.uk and google.fr

Google™ search is a trademark of Google LLC. Use of this trademark is subject to Google Permissions.

===========================

Inspired by a CodePen snippet by Twixes:
http://codepen.io/Twixes/pen/xZejZY
